(function($) {
    $.fn.menumaker = function(options) {
        var cssmenu = $(this),
            settings = $.extend({
                format: "dropdown",
                sticky: false
            }, options);

        return this.each(function() {
            // Toggle main menu
            $(this).find(".button").on('click', function() {
                $(this).toggleClass('menu-opened');
                var mainmenu = $(this).next('ul');
                mainmenu.slideToggle().toggleClass('open');
                if (settings.format === "dropdown") {
                    mainmenu.find('ul').show();
                }
            });

            cssmenu.find('li ul').parent().addClass('has-sub');
            
            // Multi-toggle submenu
            var multiTg = function() {
                cssmenu.find(".has-sub").prepend('<span class="submenu-button"></span>');
                cssmenu.find('.submenu-button').on('click', function() {
                    $(this).toggleClass('submenu-opened');
                    $(this).siblings('ul').slideToggle().toggleClass('open');
                });
            };

            if (settings.format === 'multitoggle') {
                multiTg();
            } else {
                cssmenu.addClass('dropdown');
            }

            if (settings.sticky) {
                cssmenu.css('position', 'fixed');
            }

            var resizeFix = function() {
                var mediasize = 1000;
                if ($(window).width() > mediasize) {
                    cssmenu.find('ul').show();
                } else {
                    cssmenu.find('ul').hide().removeClass('open');
                }
            };

            resizeFix();
            $(window).on('resize', resizeFix);
        });
    };
})(jQuery);

(function($) {
    $(document).ready(function() {
        $("#cssmenu").menumaker({
            format: "multitoggle",
            sticky: false
        });
    });
})(jQuery);


// Function to show tab content
function showUniqueTab(tabId) {
    // Hide all tab content
    document.querySelectorAll(".unique-tab-content").forEach(tab => {
        tab.classList.remove("active");
    });

    // Remove active class from all buttons
    document.querySelectorAll(".unique-tab-btn").forEach(button => {
        button.classList.remove("active");
    });

    // Show selected tab
    document.getElementById(tabId).classList.add("active");

    // Set active button
    document.querySelector(`[onclick="showUniqueTab('${tabId}')"]`).classList.add("active");
}

// Default to first tab
document.addEventListener("DOMContentLoaded", () => {
    showUniqueTab("unique-tab1");
});


// Function to show tab content
function showCustomTab(tabId) {
    // Hide all tab content
    document.querySelectorAll(".custom-tab-content").forEach(tab => {
        tab.classList.remove("active");
    });

    // Remove active class from all buttons
    document.querySelectorAll(".custom-tab-btn").forEach(button => {
        button.classList.remove("active");
    });

    // Show selected tab
    document.getElementById(tabId).classList.add("active");

    // Set active button
    document.querySelector(`[onclick="showCustomTab('${tabId}')"]`).classList.add("active");
}

// Default to first tab
document.addEventListener("DOMContentLoaded", () => {
    showCustomTab("custom-tab-1");
});

